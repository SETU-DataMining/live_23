def download_zipfile(url, zipF):
  if not os.path.isfile(zipF):
    with open(zipF, 'wb') as out:
      out.write(requests.get(url).content)


def read_zipfile_item(zipF, fn):
  with zipfile.ZipFile(zipF) as zip_file:
    with zip_file.open(fn) as f:
      return f.read().decode('utf8')

url = 'https://guoguibing.github.io/librec/datasets/filmtrust.zip'
zipF = 'data/filmtrust.zip'
fn = 'ratings.txt'
download_zipfile(url, zipF)
# io.StringIO converts the stream into a file-like object, as expected by pd.read_table()
ratings = pd.read_table(io.StringIO(read_zipfile_item(zipF, fn)), sep = ' ', names = ['uid', 'iid', 'rating'])
print(ratings.head())