from sklearn import preprocessing

scaler = preprocessing.StandardScaler()
scaledXarray = scaler.fit_transform(X) # Note that X is no longer a dataframe after scaling :-(
scaledX = pd.DataFrame(scaledXarray, index=X.index, columns=X.columns) # Convert it back