fig = plt.figure()
ax = fig.add_subplot(1,1,1)

ax.scatter(diamondData.carats, diamondData.price)
# draw linear regression line
x = [0.1,0.4]
y = [simpleModel.params.const + simpleModel.params.carats * i for i in x] 
ax.plot(x, y)
# Plot the fitted values as "orange" dots for comparison with the "blue" data dots 
y_hat = simpleModel.fittedvalues
ax.scatter(diamondData.carats, y_hat)
# pretty-up the plot
fig.suptitle("Relationship between diamonds' price and weight, with OLS fit")
ax.set_ylabel('Price [SIN $]')
ax.set_xlabel('Weight [carat]')
ax.grid(True)
plt.savefig("res/diamondsFit.pdf")