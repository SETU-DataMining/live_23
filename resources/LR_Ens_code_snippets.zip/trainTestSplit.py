from sklearn.model_selection import train_test_split
seed=2
Xtrain, Xtest, ytrain, ytest = train_test_split(digits.data, digits.target,
                                                random_state=seed, stratify=digits.target)
print(Xtrain.shape, Xtest.shape)