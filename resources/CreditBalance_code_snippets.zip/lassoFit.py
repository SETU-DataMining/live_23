from sklearn.linear_model import Lasso

lambdas = [0.01, 1, 10, 50, 100, 200, 500, 1000]
coefficients = np.zeros(shape=(nP, len(lambdas)))
i=0
for l in lambdas:
    lassoReg = Lasso(alpha=l)
    lassoReg.fit(scaledX, y)
    coefficients[:,i] = lassoReg.coef_
    i += 1