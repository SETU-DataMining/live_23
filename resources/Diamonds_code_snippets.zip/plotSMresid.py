residuals = simpleModel.resid
fig = plt.figure()
ax = fig.add_subplot(1,1,1)
resFig = "res/residuals.pdf"

ax.scatter(diamondData.carats, residuals)
fig.suptitle("Residuals plotted against weight")
ax.set_ylabel('Actual - Prediced Price [SIN $]')
ax.set_xlabel('Weight [carat]')
ax.grid(True)
plt.savefig(resFig)