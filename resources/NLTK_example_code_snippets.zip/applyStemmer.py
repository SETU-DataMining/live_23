from nltk.stem.porter import PorterStemmer
# Reduce words to their stems
porterStemmed = [PorterStemmer().stem(w) for w in filteredWords]
print(porterStemmed)