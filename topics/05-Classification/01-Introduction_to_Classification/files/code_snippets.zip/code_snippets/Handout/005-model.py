from sklearn.linear_model import LogisticRegression
model = LogisticRegression(max_iter=500)