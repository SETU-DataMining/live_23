from collections import Counter
fdist2 = Counter(list(bigrams(text1)))
fdist2.most_common(20)