gs = gs.fit(X_train, y_train)
print(gs.best_score_)
print(gs.best_params_)