# Create a Naive Bayes Classifier
clf=GaussianNB()

# Train the model using the training sets y_pred=clf.predict(X_test)
clf.fit(X_train_scaled,np.ravel(y_train))

# prediction on test set
y_pred=clf.predict(X_test_scaled)

showDiagnostics(y_test, y_pred)