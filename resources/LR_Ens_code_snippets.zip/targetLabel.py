# The target label
from collections import Counter # https://stackoverflow.com/a/2392948
c = Counter(digits.target)

print(c.items())