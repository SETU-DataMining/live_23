fig = plt.figure()
resFig = "res/residuals3.pdf"

ax1 = plt.subplot(1, 2, 1)
ax1.scatter(diamondData2.carats, residuals2)
ax1.set_ylabel('Actual - Prediced Price [SIN $]')
ax1.set_xlabel('Weight [carat]')

ax2 = plt.subplot(1, 2, 2)
ax2.scatter(diamondData2.quality, residuals2)
ax2.set_ylabel('Actual - Prediced Price [SIN $]')
ax2.set_xlabel('Quality [ratio]')

fig.suptitle("Residuals plotted against weight")
plt.tight_layout()
plt.savefig(resFig)