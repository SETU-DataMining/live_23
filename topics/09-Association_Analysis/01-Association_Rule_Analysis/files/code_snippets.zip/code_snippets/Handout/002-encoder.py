import pandas as pd
from mlxtend.preprocessing import TransactionEncoder

te = TransactionEncoder()
te_ary = te.fit_transform(transactions,sparse=False)

df = pd.DataFrame(te_ary, columns=te.columns_)
print(df.head())