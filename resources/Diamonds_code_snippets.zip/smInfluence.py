resFig = "res/simpleModel_influence.pdf"
fig = sm.graphics.influence_plot(simpleModel, criterion="cooks")
fig.tight_layout(pad=1.0)
fig.savefig(resFig)