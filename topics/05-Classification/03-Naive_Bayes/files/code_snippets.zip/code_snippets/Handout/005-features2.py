count_vectorizer.fit(X_train)
X_train_counts = count_vectorizer.transform(X_train)