# See https://stackoverflow.com/a/50662956/1988855
from pathlib import Path
# See https://stackoverflow.com/a/65907473/1988855
import ipynbname

try:
    fname = Path(__file__).stem
except NameError:
    fname = ipynbname.name().replace(".ipynb","")
print(fname)

dataDir = "data"
# Make sure the outputDir subdirectory exists
outputDir = "output/" + fname
import os, errno
try:
    os.makedirs(outputDir)
except OSError as e:
    if e.errno != errno.EEXIST:
        raise
import numpy as np

distMatrix = np.array([
    (0,  9,  3, 6, 11),
    (9,  0,  7, 5, 10),
    (3,  7,  0, 9, 2),
    (6,  5,  9, 0, 8),
    (11, 10, 2, 8, 0)
])
condensed = [9, 3, 6, 11, 7, 5, 10, 9, 2, 8]