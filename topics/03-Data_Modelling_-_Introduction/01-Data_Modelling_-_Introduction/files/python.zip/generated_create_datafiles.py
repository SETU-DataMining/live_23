#!/usr/bin/env python3

# generate data files in folder data/generated_1
# based on example dataset from scikit

import numpy as np

def true_fun(X):
    return np.cos(1.5 * np.pi * X)

np.random.seed(0)

n_samples = 300

X = np.random.rand(n_samples)
y = true_fun(X) + np.random.randn(n_samples) * 0.1

data = np.transpose(np.array([X,y]))

for k in [30,300]:
    filename = 'data/generated/sample_%03d.csv' % k
    sample = data[:k]
    sample = sample[sample[:,0].argsort()]
    np.savetxt(filename, sample, delimiter=',', fmt='%8.4f')
    
sample = data[30:60]
sample = sample[sample[:,0].argsort()]
np.savetxt('data/generated/test_030.csv', sample, delimiter=',', fmt='%8.4f')