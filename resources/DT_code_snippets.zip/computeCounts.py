rowCount = {}
rowCount["ALL"] = len(df.index)
colNames = list(df.columns.values)
className = "play"
labels = {}
for colName in colNames:
  labels[colName] = df[colName].unique().tolist()
  rowCount[colName] = {}
  for label in labels[colName]:
    rowCount[colName][label] = len(df.loc[df[colName] == label].index)
pp.pprint(rowCount)