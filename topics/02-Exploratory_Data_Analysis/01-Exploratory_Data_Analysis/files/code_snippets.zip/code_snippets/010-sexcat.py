df.sex = pd.Categorical(df.sex)
df.sex.unique()