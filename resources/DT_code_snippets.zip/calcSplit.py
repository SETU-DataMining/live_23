for predName in predNames:
  term = 0
  predNameB = '["'+predName+'"]'
  for predLabel in labels[predName]:
    predLabelB = '["'+predLabel+'"]'
    p = "(" + str(rowCount[predName][predLabel]) + "/" + str(rowCount["ALL"]) + ") * "
    a = p + "("+calcH(predNameB,predLabelB,pd=rowCount[predName][predLabel])+")"
    if (term == 0):
      acc = a
    else:
      acc = acc + " + " + a
    term += 1
  H[className][predName] = eval(acc)

  print(acc)
  print("Splitting on {} gives entropy {}".format(predName,H[className][predName]))