import numpy as np

# Fit the classifiers and output the crossVal results
for name, model in models:
    # We use k-fold cross validation, where 10% of the training data is held back each time 
    kfold = model_selection.KFold(n_splits=nSplits, random_state=seed, shuffle=True)
    crossValResults = model_selection.cross_val_score(
        model, X_train_scaled, np.ravel(y_train), cv=kfold, scoring='accuracy')
    results.append(crossValResults)
    names.append(name)
    # Now print the results
    print("%s: %f (%f)" % (name, crossValResults.mean(), crossValResults.std()))