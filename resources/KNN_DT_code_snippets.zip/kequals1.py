from sklearn.neighbors import KNeighborsClassifier
X, y = iris.data, iris.target
knn1 = KNeighborsClassifier(n_neighbors=1)
knn1.fit(X, y)
y_pred1 = knn1.predict(X)
print(np.all(y == y_pred1))