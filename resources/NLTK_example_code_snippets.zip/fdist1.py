fdist1 = FreqDist(text1)
fdist1.most_common(40)