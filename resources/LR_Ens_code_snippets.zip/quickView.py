# The images themselves
print(digits.images.shape)
print(digits.images[0])