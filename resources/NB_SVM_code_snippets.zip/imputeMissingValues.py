adjustedPimaDf = pimaDf.copy()

for col in nullablePredNames:
  # Calculate the median value
  medianVal = pimaDf.loc[pimaDf[col] != 0][col].median()
  adjustedPimaDf.loc[pimaDf[col] == 0, col] = medianVal

adjustedPimaDf.head()