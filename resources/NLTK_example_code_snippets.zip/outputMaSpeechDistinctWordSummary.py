print("Number of distinct words without punctuation {}".format(len(set(words))))
print("Number of distinct words without punctuation and stopwords {}".format(len(set(filteredWords))))
print("Number of such distinct words following stemming {}".format(len(set(porterStemmed))))
print("Number of such distinct words following lemmatisation {}".format(len(set(wnLemmed))))