from sklearn.metrics import classification_report
print(classification_report(y_test, y_pred, target_names=target_names))