df["Weight"] = pd.to_numeric(df["Weight"])
df["Weight"].dtype