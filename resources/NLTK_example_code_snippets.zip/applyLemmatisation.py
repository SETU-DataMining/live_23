#nltk.download('omw-1.4')
from nltk.stem.wordnet import WordNetLemmatizer
# Reduce words to their root form
wnLemmed = [WordNetLemmatizer().lemmatize(w) for w in filteredWords]
print(wnLemmed)