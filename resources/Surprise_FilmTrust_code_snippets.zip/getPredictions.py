testset = [[50, iid, -1] for iid in iids_to_pred]
predictions = alg.test(testset)