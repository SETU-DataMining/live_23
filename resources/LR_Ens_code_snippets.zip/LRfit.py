from sklearn.linear_model import LogisticRegression

# Get and configure a LogisticRegression object, with an L2 regularisation penalty
clf = LogisticRegression(penalty='l2', max_iter=7600)

# Fit the training data
clf.fit(Xtrain, ytrain)

# Using the beta parameters that have just been learned and are in clf, predict (recognise) the test data
ypred = clf.predict(Xtest)