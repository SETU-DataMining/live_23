import math
import pandas as pd
import pprint
pp = pprint.PrettyPrinter(indent=2)
dataDir = "data"
df = pd.read_csv(dataDir+"/playTennis.csv",header=0,quotechar="'")
print(df)