# prepare model
trainingSet = X_train.assign(DiabetesClass=y_train)
summaries = summarizeByClass(trainingSet)
# test model
testSet = X_test.assign(DiabetesClass=y_test)
predictions = getPredictions(summaries, testSet)
accuracy = getAccuracy(testSet, predictions)
print('Accuracy: {0}%'.format(accuracy))