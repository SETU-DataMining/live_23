print(pimaDf.shape)
predNames = ['NumPreg', 'PlasmaGlucose', 'DiastolicBP', 'SkinFold', 'SerumInsulin', 'BMI', 'PedFn', 'AgeYrs']
className = 'DiabetesClass'
colNames = predNames + [className]

pimaDf.columns = colNames
pimaDf.head()