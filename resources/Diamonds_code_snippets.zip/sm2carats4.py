resFig = "res/simpleModel2_carats_4plot.pdf"
fig = sm.graphics.plot_regress_exog(simpleModel2, "carats")
fig.tight_layout(pad=1.0)
fig.savefig(resFig)