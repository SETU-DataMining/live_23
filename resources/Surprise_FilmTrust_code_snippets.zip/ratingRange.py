# Get the rating range
lowest_rating = ratings['rating'].min()
highest_rating = ratings['rating'].max()
print('Ratings range from {0} to {1}'.format(lowest_rating, highest_rating))