pipeline = Pipeline([
    ('scl', StandardScaler()),
    ('clf', SVC(kernel='rbf', random_state=SEED))
])

from sklearn.model_selection import RandomizedSearchCV
from scipy.stats import randint

param_range = np.logspace(-4,4,40)

param_grid = {'clf__C': param_range,
              'clf__gamma': param_range}

rs = RandomizedSearchCV(estimator=pipeline, 
    param_distributions=param_grid,
    n_iter = 81, random_state=SEED,
    return_train_score=True,
    scoring='accuracy', cv=10, n_jobs=-1)