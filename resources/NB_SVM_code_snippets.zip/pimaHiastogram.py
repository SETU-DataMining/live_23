import matplotlib.pyplot as plt
%matplotlib inline

pimaDf.hist(bins=50, figsize=(20, 15))
plt.show()