# Change to lower case and tokenise
from nltk.tokenize import word_tokenize
lcWords = word_tokenize(text.lower())

# Remove stopwords
from nltk.corpus import stopwords
stopWords = stopwords.words('english')
filteredWords = [w for w in lcWords if w not in stopWords]

# Remove punctuations, including an additional quote types
import string
punctuationMarks = list(string.punctuation)
words = [w for w in filteredWords if (w not in punctuationMarks) and (w not in ('“','”','’'))]