model.fit(X[['Gender']], y)
[model.intercept_, model.coef_]