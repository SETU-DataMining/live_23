reader = surprise.Reader(rating_scale=(lowest_rating, highest_rating))
data = surprise.Dataset.load_from_df(ratings, reader)