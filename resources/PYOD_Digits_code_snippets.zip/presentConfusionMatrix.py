trueInlier, falseOutlier, falseInlier, trueOutlier = confusion_matrix(y_test, y_test_pred).ravel()
print("There were {} digits, of which".format(n_test))
print("{} inliers were classified correctly; {} outliers were classified correctly.".format(trueInlier,trueOutlier))
print("{} outliers were classified incorrectly; {} inliers were classified incorrectly.".format(falseOutlier,falseInlier))