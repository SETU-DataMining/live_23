vNames = ["v"+str(i) for i in range(100)]
zipDataFile = 'data/mnist.zip'
matDataFile = 'data/mnist.mat'
if path.exists(matDataFile):
    print("Read {}".format(matDataFile))
    mnist = loadmat(matDataFile)
    X = pd.DataFrame(data=mnist['X'], columns=vNames)
    y = pd.DataFrame(data=mnist['y'], columns=['label'])
elif path.exists(zipDataFile):
    print("Read {}".format(zipDataFile))
    with ZipFile(zipDataFile, mode='r') as dataZip:
        # Read the predictor (X) matrix based on the selected pixel columns
        with dataZip.open('X.csv') as mnistX:
            X = pd.DataFrame(data=pd.read_csv(mnistX,header=None), columns=vNames)
        # Read the label (y) vector where
        with dataZip.open('y.csv') as mnistY:
            y = pd.DataFrame(data=pd.read_csv(mnistY,header=None), columns=['label'])
else:
    #with urllib.request.urlopen('https://www.dropbox.com/s/n3wurjt8v9qi6nc/mnist.mat') as response:
    #    with open("mnist.mat", "wb") as f:
    #        f.write(response.read())
    print('download the file using wget')
X.shape