range_n_clusters = [2, 3, 4, 5, 6]

#print(__doc__)
clustererName = "KMeans"
inertiaList = []
silhouetteList = []

outputDir = "output/Practical_F_scores/"
import os, errno
try:
    os.makedirs(outputDir)
except OSError as e:
    if e.errno != errno.EEXIST:
        raise