pos_tagged_text = nltk.pos_tag(words)
print(pos_tagged_text)