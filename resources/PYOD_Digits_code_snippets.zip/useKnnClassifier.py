from pyod.models.knn import KNN

knn=KNN(contamination=outlier_fraction)
knn.fit(X_train)

# get the prediction labels of the training data
y_train_pred = knn.labels_ 
y_train_pred