def no_style(row):
    style = ''
    return [style] * len(row)
df.style.apply(no_style, axis=1)