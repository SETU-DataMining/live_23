diamondData2 = diamondData.copy()
diamondData2.insert(1,'quality',residuals,False)
from sklearn.preprocessing import MinMaxScaler
scaler = MinMaxScaler()
diamondData2[['quality']] = scaler.fit_transform(diamondData2[["quality"]]).round(1)
diamondData2.head()