fig, ax = plt.subplots()

plt.title("Lasso Regularisation")
plt.xlabel("lambda")
plt.ylabel("standardised coefficients")
styles=['-','--','-.',':']

labels = ['0.01','1','10','50', '100', '200','500','1000']

# See https://stackoverflow.com/a/63755285/1988855

# Outdated code, generates warning but works
ax.set_xticklabels(labels) # custom x labels

chosenPredictors = {"Income", "Rating", "Student"}
for i in range(0,12):
    s = styles[i % len(styles)]
    if predictors[i] in chosenPredictors:
        plt.plot(coefficients[i], label=predictors[i], linestyle=s)
    else:
        plt.plot(coefficients[i])

plt.legend(loc='best')
resFig = "res/lasso.pdf"
plt.savefig(resFig)