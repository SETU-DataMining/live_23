y = data['Balance'].copy() # this is the Credit Balance vector - our 'y' vector
X = data.copy()
X.drop(['Balance'], axis=1, inplace=True) # X is a copy of the dataframe but with the 'Balance' vector removed, leaving just the matrix of predictors `X`.