from sklearn import datasets
digits = datasets.load_digits()
digits.images.shape