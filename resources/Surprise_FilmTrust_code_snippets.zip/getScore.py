# The uids and iids need to be converted to strings for prediction
pred = alg.predict(uid='1', iid='4')
predScore = pred.est
actualScore = ratings.query('uid == "1" & iid == "4"').iloc[0]['rating']
print('Actual score is {0} and predicted score (using SVD-based recommender algorithm) is {1}'.format(actualScore,predScore))