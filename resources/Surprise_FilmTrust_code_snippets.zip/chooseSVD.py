alg = surprise.SVD()
output = alg.fit(data.build_full_trainset())