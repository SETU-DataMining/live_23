df.smoker = pd.Categorical(df.smoker)
df.smoker.unique()