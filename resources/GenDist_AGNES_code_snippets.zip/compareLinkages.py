import matplotlib.pyplot as plt
from scipy.cluster.hierarchy import linkage, dendrogram
import time

%matplotlib inline

algName = "AgglomerativeClustering"
labels = ('A','B','C','D','E')
for link in ['complete', 'single', 'average', 'ward']:
    plt.figure()
    start_time = time.time()
    Z = linkage(condensed, method=link)
    end_time = time.time()
    plt.figure(figsize=(6, 4))
    plt.title(algName+" : "+link)
    R = dendrogram(Z, labels=labels, truncate_mode=None)
    plt.savefig(outputDir + '/AGNES'+link+'.pdf')
    elapsed_time = end_time-start_time
#    print(elapsed_time)