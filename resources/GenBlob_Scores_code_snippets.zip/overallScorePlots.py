fig =  cs.plotInertiaSilhouette(range_n_clusters, clustererName, inertiaList, silhouetteList, outputDir, plt)
plt.show()