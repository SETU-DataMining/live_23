predNames = [x for x in colNames if className not in x]
for predName in predNames:
  rowCount[className][predName] = {}
  for classLabel in labels[className]:
    rowCount[className][predName][classLabel] = {}
    for predLabel in labels[predName]:
      rowCount[className][predName][classLabel][predLabel] = len(df.loc[(df[className] == classLabel) & (df[predName] == predLabel)].index)
pp.pprint(rowCount)