import re
text = re.sub(r"[^a-zA-Z0-9]", " ", maSpeech.lower())
print(text)