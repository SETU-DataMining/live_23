ethnicityIndicators = pd.get_dummies(X['Ethnicity'])
X = X.join(ethnicityIndicators)
X.drop(['Ethnicity'], axis=1, inplace=True)