import numpy as np
plt.imshow(np.sqrt(confusionMat),cmap='Blues', interpolation='nearest')
plt.grid(False)
plt.ylabel('true')
plt.xlabel('predicted');
plt.savefig(picDir+"/logreg_digits_l2_confusionMatrix.pdf")