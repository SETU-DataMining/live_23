df = pd.read_csv("train.csv")
sns.catplot(data=df, x="Fare", y="Survived");