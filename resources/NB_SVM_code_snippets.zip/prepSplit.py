X = filteredPimaDf[predNames]
y = filteredPimaDf[['DiabetesClass']]

# Import train_test_split function
from sklearn.model_selection import train_test_split

# Split dataset into training and test sets
def splitData(X, y):
  testSize=0.33
  randomState=5
  X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=testSize, stratify=y, random_state=randomState)
  return X_train, X_test, y_train, y_test

X_train, X_test, y_train, y_test = splitData(X, y)
print('Split {0} rows into train={1} and test={2} rows'.format(len(pimaDf.index), len(X_train.index), len(X_test.index)))