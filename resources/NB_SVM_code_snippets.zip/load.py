dataDir = "../data"
dataFile = dataDir + '/pima-indians-diabetes.csv'

# See https://stackoverflow.com/a/82852
import os.path
if not os.path.isfile(dataFile):
  import requests # Remember: you may need to install the requests module: conda install -c anaconda requests 
  
  url = 'https://gist.github.com/chaityacshah/899a95deaf8b1930003ae93944fd17d7/raw/3d35de839da708595a444187e9f13237b51a2cbe/pima-indians-diabetes.csv'
  r = requests.get(url)

  # See https://stackoverflow.com/a/273227
  os.makedirs(dataDir, exist_ok=True)
  with open(dataFile, 'wb') as f:
    f.write(r.content)
    
import pandas as pd
pimaDf = pd.read_csv(dataFile)
pimaDf.head()