#!/usr/bin/env python3

import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns 
sns.set()
DPI = 100

def true_fun(X):
    return np.cos(1.5 * np.pi * X)

from sklearn import linear_model
from sklearn.metrics import mean_squared_error

data = np.loadtxt('data/generated/sample_030.csv', delimiter=',')
X_train, y_train = data[:,0], data[:,1] 

data = np.loadtxt('data/generated/test_030.csv', delimiter=',')
X_test, y_test = data[:,0], data[:,1] 

def generate_fit_linear_reg(degree, show_true=False, save_fig=False, show_test=False, label="", show_fig=False):

    X_train_regr = np.array([[r**(k+1) for k in range(degree)] for r in X_train])
    regr = linear_model.LinearRegression()
    regr.fit(X_train_regr, y_train)
    y_train_pred = regr.predict(X_train_regr)
    
    score_train = mean_squared_error(y_train, y_train_pred)  # scoring on train set is BAAAAD

    X_test_regr = np.array([[r**(k+1) for k in range(degree)] for r in X_test])
    y_test_pred = regr.predict(X_test_regr)
    score_test = mean_squared_error(y_test, y_test_pred)
        
    X_plot = np.linspace(0, 1, 100)
    x_plot_regr = np.array([[r**(k+1) for k in range(degree)] for r in X_plot])
    plt.clf()
    plt.plot(X_plot, regr.predict(x_plot_regr), 'g', label="Model")
    if show_true: plt.plot(X_plot, true_fun(X_plot), label="True function")
    plt.scatter(X_train, y_train, edgecolor='b', s=20, label="Samples")
    plt.xlabel("x")
    plt.ylabel("y")
    plt.xlim((0, 1))
    plt.ylim((-1.5, 1.5))
    plt.legend(loc="best")
    if show_test:
        plt.title("Degree %s (m=%d) \nMSE = %.2e   (train) %.2e (test)" % (degree, len(y_train), score_train, score_test))
    else:
        plt.title("Degree %s (m=%d)\nMSE = %.2e" % (degree, len(y_train), score_train))

    if save_fig:
        filename = 'generated_fit_%d_%s_%s_linear%s.pdf' % (
                degree, "T" if show_true else "F", "T" if show_test>0 else "F", label)
        plt.savefig(filename, dpi=DPI, bbox_inches='tight')

    if show_fig: plt.show()
    return [score_train, score_test]

# generate plots to show effect of degree on MSE

degrees = range(1,21)
scores = {}
for i, degree in enumerate(degrees):
    scores[degree] = generate_fit_linear_reg(degree, save_fig=True)
generate_fit_linear_reg( 4, show_true=True, save_fig=True)
generate_fit_linear_reg(15, show_true=True, save_fig=True)
plt.close()

# plot of MSE vs degree

xs = [x for x in range(1,21)]
scores_train = [scores[x][0] for x in xs]
scores_test = [scores[x][1] for x in xs]    

plt.semilogy(xs,scores_train, "o-", label="MES")
plt.title("Effect of meta-parameter (k) on MSE")
plt.ylabel('log(MSE)')
plt.xlabel("Degree")
plt.xticks(range(1,21),range(1,21))
plt.savefig("generated_MSE_train.pdf", dpi=DPI, bbox_inches='tight')
print("generated_MSE_train DONE")
plt.close()

# plot of MSE (test and train) vs degree

plt.semilogy(xs,scores_train, "o-", label="MES (train)")
plt.semilogy(xs,scores_test, "o-", label="MES (test)")
plt.title("Effect of meta-parameter (k) on MSE")
plt.ylabel('log(MSE)')
plt.xlabel("Degree")
plt.xticks(range(1,21),range(1,21))
plt.legend();
plt.savefig("generated_MSE_train_and_test.pdf", dpi=600, bbox_inches='tight')
print("generated_MSE_train_and_test DONE")
plt.close()

# plots to show relationship between degree and number of observations used

sample_permuataion = np.random.permutation(range(len(X_train)))
data = np.loadtxt('data/generated/sample_030.csv', delimiter=',')
X_train_all, y_train_all = data[:,0], data[:,1]

n = 10
for degree in [1,5,15]:
    for n in [5,10,15,20,30]:
        X_train = X_train_all[sample_permuataion[:n]]
        y_train = y_train_all[sample_permuataion[:n]]
        generate_fit_linear_reg(degree, save_fig=True, show_test=True, label="_n%s" % n)
        
#
# learning curve
data = np.loadtxt('data/generated/sample_030.csv', delimiter=',')
X_train_all, y_train_all = data[:,0], data[:,1] 
sample_permuataion = np.random.permutation(range(len(X_train_all)))

for degree in [1,5,15]:
    scores = {}
    for n in range(3,31,2):
        X_train = X_train_all[sample_permuataion[:n]]
        y_train = y_train_all[sample_permuataion[:n]]
        scores[n] = generate_fit_linear_reg(degree)
    xs = list(scores.keys())
    scores_train = [max(scores[x][0],1e-5) for x in xs]
    scores_test = [max(scores[x][1],1e-5) for x in xs]
    plt.close()
    plt.semilogy(xs, scores_train, label="MES (train)")
    plt.plot(xs, scores_test, label="MES (test)")
    plt.title("Learning Curve (degree=%d)" % degree)
    plt.ylabel('log(MSE)')
    plt.ylim(1e-4,1e3)
    plt.xlim(5,30)
    plt.xlabel("Number of observations")
    plt.savefig("generated_learning_curve_%d.pdf" % degree , dpi=DPI, bbox_inches='tight')
    plt.close()
    
