df = pd.read_csv("train.csv")
df.Survived = pd.Categorical(df.Survived)
sns.catplot(data=df, x="Fare", y="Survived");