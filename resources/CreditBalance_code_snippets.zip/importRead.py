import pandas as pd
from sklearn import linear_model
import os
if not os.path.exists('res'):
    os.makedirs('res')

dataFile = "data/Credit.csv"
data = pd.read_csv(dataFile, index_col=0) 

data.shape