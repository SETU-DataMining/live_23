import os
picDir = "output/pics"
if not os.path.exists(picDir):
    os.makedirs(picDir)