df["Weight"] = df["Weight"].astype('float')
df["Weight"].dtype