nullablePredNames = predNames.copy()
try:
  nullablePredNames.remove('NumPreg')
except ValueError:
  pass

filteredPimaDf = pimaDf.copy()

for col in nullablePredNames:
  filteredPimaDf.loc[pimaDf[col] == 0, col] = None

filteredPimaDf.head()