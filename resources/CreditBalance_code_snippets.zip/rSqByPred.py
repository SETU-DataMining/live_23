import matplotlib.pyplot as plt

plt.title("Score versus predictors")
plt.xlabel('Number of predictors') 
plt.ylabel('R squared')
plt.plot(scores)
resFig = "res/rSqByPred.pdf"
plt.savefig(resFig)