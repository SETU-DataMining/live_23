print("Number of words without punctuation {}".format(len(words)))
print("Number of words without punctuation and stopwords {}".format(len(filteredWords)))
print("Number of such words following stemming {}".format(len(porterStemmed)))
print("Number of such words following lemmatisation {}".format(len(wnLemmed)))