df = pd.read_csv('Marks.csv', sep=',')
print(df.shape)
df.head()