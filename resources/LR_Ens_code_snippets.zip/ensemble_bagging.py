from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import BaggingClassifier

# Configure the bagging classifier
n_estimators=50
baggingClf = BaggingClassifier(base_estimator=DecisionTreeClassifier(),
                        n_estimators=n_estimators, random_state=0).fit(Xtrain, ytrain)
ypredBagging = clf.predict(Xtest)