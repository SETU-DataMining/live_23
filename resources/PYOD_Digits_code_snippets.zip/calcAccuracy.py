accuracy = (n_test-n_errors)/float(n_test)
print('Accuracy when applying knn to test set: {}'.format(accuracy))