import numpy as np
from sklearn.neural_network import MLPClassifier

xs = np.array([[0, 0],[0, 1],[1, 0],[1, 1]])
ys = np.array([0, 1, 1, 0])

for activation in ['logistic', 'relu']:
    print ("\nUsing activation %s" % activation)

    model = MLPClassifier(
        activation=activation, 
        max_iter=10000, 
        hidden_layer_sizes=(2,),
        random_state=20)

    model.fit(xs, ys)
    
    print('score:', model.score(xs, ys)) 
    print('predictions:', model.predict(xs))
    print('expected:', ys)