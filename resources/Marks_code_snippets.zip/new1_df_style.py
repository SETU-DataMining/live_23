def tmp(row):
    style = 'background-color: %s' % 'lightgreen' 
    return [''] * (len(row)-1) + [style]
df.style.apply(tmp, axis=1)