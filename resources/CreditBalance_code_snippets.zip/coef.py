model.fit(scaledX, y)
predictors = scaledX.columns
coef = pd.Series(model.coef_,predictors).sort_values()
coef