X = adjustedPimaDf[predNames]
y = adjustedPimaDf[['DiabetesClass']]

X_train, X_test, y_train, y_test = splitData(X, y)
print('Split {0} rows into train={1} and test={2} rows'.format(len(pimaDf.index), len(X_train.index), len(X_test.index)))