n_outlier = len(y[(y['label']==1)])
outlier_fraction = n_outlier / float(n_all)
print('The entire set has {} rows with {} outliers so the outlier fraction is {}'.format(n_all,n_outlier,outlier_fraction))