def tmp(row):
    k = row.Student + row.Module
    
    style = 'background-color: %s' %  group_color[k]
    return [style] * (len(row))

_.style.apply(tmp, axis=1)