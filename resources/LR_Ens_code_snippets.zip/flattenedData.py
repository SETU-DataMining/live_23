# The flattened data that is used to train the model.
print(digits.data.shape)
print(digits.data[0])