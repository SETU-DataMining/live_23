X = df.iloc[:, 2:].values
y = df.diagnosis.values