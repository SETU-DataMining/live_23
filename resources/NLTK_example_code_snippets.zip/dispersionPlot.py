import numpy as np
import matplotlib.pyplot as plt
text4.dispersion_plot(["citizens", "democracy", "freedom", "duties", "America"])