from sklearn import neighbors, datasets
import pandas as pd

iris = datasets.load_iris()
print(dir(iris)) # Note that it is not a dataframe, more a generalised data object
print(iris.feature_names)
X, y = iris.data, iris.target

# create the model
knn = neighbors.KNeighborsClassifier(n_neighbors=5)

# fit the model
knn.fit(X, y)