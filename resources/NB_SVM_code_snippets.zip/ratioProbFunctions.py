# Example of Naive Bayes implemented from Scratch in Python
# Based on https://machinelearningmastery.com/naive-bayes-classifier-scratch-python/
import math
import numpy as np

def separateByClass(dataset):
  # Given a dataset, return a dict named _separated_
  # The dict keys are the class labels
  # The dict value for each key lis a list of the rows associated with that key
  separated = {}
  for index, row in dataset.iterrows():
    # Note that row[-1] is the last element in the row and is the assigned class label
    label = row[-1]
    if (label not in separated):
      # This is the first time we have met this class label, so create an empty list
      separated[label] = []
    separated[label].append(row)
  return separated

def summarize(dataset):
  # Create (mean, stdev) tuples for each column in the given dataset, returning it as a list
  summaries = [(np.mean(attribute), np.std(attribute)) for attribute in zip(*dataset)]
  # remove the last element of the list, because we are not interested in the summarised class labels
  del summaries[-1]
  return summaries

def summarizeByClass(dataset):
  # Use separateByClass to generate the subsets of the rows by classLabel
  # Then compute the list of (mean,stdev) tuples for each predictor, for each classLabel
  separated = separateByClass(dataset)
  summaries = {}
  for classValue, instances in separated.items():
    summaries[classValue] = summarize(instances)
  return summaries

def calculateProbability(x, mean, stdev):
  # Compute the Gaussian(mean,stdev) probability evaluated at x
  exponent = math.exp(-(math.pow(x-mean,2)/(2*math.pow(stdev,2))))
  return (1 / (math.sqrt(2*math.pi) * stdev)) * exponent

def calculateClassProbabilities(summaries, inputVector):
  # Given the training summaries, and a row from the testSet,
  # compute the probability of each of the class labels
  probabilities = {}
  # Loop over the classValues...
  for classValue, classSummaries in summaries.items():
    probabilities[classValue] = 1
    # Loop over the summarised predictors
    for i in range(len(classSummaries)):
      mean, stdev = classSummaries[i]
      # Note that x is the value of the associated predictor in the test instance
      x = inputVector[i]
      # Now calculate the Gaussian probability for this x
      # We accumulate this predictor's probability by multiplying it with all the others
      probabilities[classValue] *= calculateProbability(x, mean, stdev)
  return probabilities
      
def predict(summaries, inputVector):
  # Given the training summaries, and a row from the testSet,
  # compute the probability of each of the class labels
  probabilities = calculateClassProbabilities(summaries, inputVector)
  bestLabel, bestProb = None, -1
  # Now look for the bestLabel, which is associated with the highest probability
  for classValue, probability in probabilities.items():
    if bestLabel is None or probability > bestProb:
      bestProb = probability
      bestLabel = classValue
  return bestLabel

def getPredictions(summaries, testSet):
  # Given (mean,stdev) summaries (by predictor, by classLabel) from the training data,
  # compute predicted classLabels for each row in testSet, storing them in a list
  predictions = []
  for index, row in testSet.iterrows():
    result = predict(summaries, row)
    # Add the predicted classLabel to the predictions list
    # Strictly, predictions should be a pandas series, so its index can match that of the testSet
    predictions.append(result)
  return predictions

def getAccuracy(testSet, predictions):
  # Compute the accuracy as a % of correct predictions over all predictions
  correct = 0
  i = 0
  for index, row in testSet.iterrows():
    # Accumate the cases where the assigned classLabel matches the predicted classLabel
    if row[-1] == predictions[i]:
      correct += 1
    i += 1
  return (correct/float(len(testSet))) * 100.0

