print(accuracy_score(ytest, ypredBagging))
confusionMatBagging = confusion_matrix(ytest, ypredBagging)
print(confusionMatBagging)

import seaborn as sns
plt.figure(figsize=(10,7))
sns.set(font_scale=1.4) # for label size
sns.heatmap(confusionMatBagging, annot=True, annot_kws={"size": 16}) # font size
plt.show()