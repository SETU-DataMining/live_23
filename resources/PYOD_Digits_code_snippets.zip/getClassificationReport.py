from sklearn.metrics import classification_report
print(classification_report(y_test, y_test_pred))