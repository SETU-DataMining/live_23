words = maSpeech.split()
print(words)