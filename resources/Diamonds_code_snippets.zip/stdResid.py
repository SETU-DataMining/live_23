standardisedResiduals = simpleModel.resid / RMSE
upperExtreme = max(standardisedResiduals)
lowerExtreme = min(standardisedResiduals)
[lowerExtreme, upperExtreme]