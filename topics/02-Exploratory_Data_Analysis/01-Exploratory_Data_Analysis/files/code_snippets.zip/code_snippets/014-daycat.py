df.day = pd.Categorical(df.day, categories=['Thur', 'Fri','Sun', 'Sat'], ordered=True)
df.day.unique()