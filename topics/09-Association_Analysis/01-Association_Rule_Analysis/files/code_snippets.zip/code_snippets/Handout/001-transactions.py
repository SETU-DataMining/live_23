from pprint import pprint
transactions = [
   line.split(',') for line in open("toy.txt").read().split("\n")
]
pprint(transactions)