def calcH(predNameB,predLabelB,pd):
  acc = ""
  for classLabel in labels[className]:
    pns = "rowCount[className]"+predNameB+"[classLabel]"+predLabelB
    pn = eval(pns)
    p = "("+str(pn) +"/" + str(pd)+")"
    if (pn == 0):
      acc += " -" + p + " "
    else:
      acc += " -" + p + " * math.log(" + p + ", 2) "
  return acc