plt.figure(figsize=(4,6))
sns.histplot(x="a6", data=df);