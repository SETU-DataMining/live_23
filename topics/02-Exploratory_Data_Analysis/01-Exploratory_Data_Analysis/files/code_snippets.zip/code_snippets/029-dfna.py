df = df.loc[df.isna().sum(axis=1)<6].copy()
print(df.shape)