%matplotlib inline
import matplotlib.pyplot as plt