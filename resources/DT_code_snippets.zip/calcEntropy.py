H = {}
H[className] = {}
acc = calcH(predNameB="",predLabelB="",pd=rowCount["ALL"])
H[className][""] = eval(acc)

print(acc)
print(H[className][""])