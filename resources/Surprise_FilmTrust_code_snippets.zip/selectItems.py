# Get a list of all movie ids
iids = ratings['iid'].unique()
# Get a list of iids that user '50' has rated
iids50 = ratings.loc[ratings['uid']==50, 'iid']
# Remove the  iids that user 50 has rate from all the list of movie ids
iids_to_pred = np.setdiff1d(iids, iids50)