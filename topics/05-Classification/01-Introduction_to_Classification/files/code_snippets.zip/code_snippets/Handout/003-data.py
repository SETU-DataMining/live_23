dataset_name = "IRIS"
X, y, target_names = iris.data[:,:2], iris.target, iris.target_names