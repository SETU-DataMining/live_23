plt.title("Lambda tuning for Lasso Regularisation")
plt.xlabel("lambda")
plt.ylabel("Cross-Validation error (MSE)")

plt.plot(lambdas,scoresCV)
resFig = "res/lambdaLassoCV.pdf"
plt.savefig(resFig)