from sklearn.metrics import accuracy_score, confusion_matrix
print(accuracy_score(ytest, ypred))
confusionMat = confusion_matrix(ytest, ypred)
print(confusionMat)