speechDf['year'] = pd.DatetimeIndex(speechDf['Date']).year
speechDf['year_Name'] = speechDf['year'].astype(str).str.cat(speechDf[['Name']], sep="_")
speechDf.head()