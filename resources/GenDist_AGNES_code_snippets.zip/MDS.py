from sklearn.manifold import MDS

embedding = MDS(n_components=2, dissimilarity='precomputed')
X = embedding.fit_transform(distMatrix)

plt.scatter(X[:,0], X[:,1], s=100, c='orange')
plt.axis('square')
plt.title('MDS: Embedded points in 2-D')
plt.savefig(outputDir + '/AGNES_MDS.pdf')