df = pd.read_csv('marks.csv', sep=',')
print(df.shape)
df.head()