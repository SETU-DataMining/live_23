n_errors = (y_test_pred != yTest).sum()
print('No of Errors when applying knn to test set: {}'.format(n_errors))