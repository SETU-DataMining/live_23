model = Sequential()

layer = Dense(3, activation='relu', 
    kernel_initializer=initialize_weights, input_dim=2)
model.add(layer)

layer = Dense(1, activation='sigmoid')
model.add(layer)

model.compile(loss='mean_squared_error', 
    optimizer='adam', metrics='accuracy')

model.fit(X, y, batch_size=4, epochs=1000, verbose=0)

pred_prob = model.predict(X)
summary(model,X,y)