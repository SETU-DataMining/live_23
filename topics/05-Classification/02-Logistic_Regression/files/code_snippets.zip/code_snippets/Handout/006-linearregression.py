from sklearn.linear_model import LinearRegression
model = LinearRegression()