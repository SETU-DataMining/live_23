for n_clusters in range_n_clusters:
    # Create a subplot with 1 row and 2 columns
    fig, (ax1, ax2) = plt.subplots(1, 2)
    fig.set_size_inches(18, 7)

    # Initialize the clusterer with n_clusters value and a random generator
    # seed of 10 for reproducibility.
    clusterer = KMeans(n_clusters=n_clusters, random_state=10)
    cluster_labels = clusterer.fit_predict(X)

    # Append inertia attribute
    inertiaList.append(clusterer.inertia_)

    # The silhouette_score gives the average value for all the samples.
    # This gives a view of the density and separation of the formed
    # clusters
    silhouette_avg = silhouette_score(X, cluster_labels)
    print("For n_clusters =", n_clusters,
          "The average silhouette_score is :", silhouette_avg)

    # Append silhouette score
    silhouetteList.append(silhouette_avg)

    # Compute the silhouette scores for each sample
    sample_silhouette_values = silhouette_samples(X, cluster_labels)

    ax1 = cs.plotSilhouetteClusters(n_clusters, cluster_labels, X, sample_silhouette_values, silhouette_avg, ax1)

    # 2nd Plot showing the actual clusters formed
    featureName = ["f1","f2"]
    ax2 = cs.plotDataWithClusters(n_clusters, cluster_labels, clusterer, X, featureName, ax2)

    plt.suptitle(("Silhouette analysis for " + clustererName + " clustering on sample data "
                  "with n_clusters = %d" % n_clusters),
                 fontsize=14, fontweight='bold')
    fig.savefig(outputDir+"s"+str(n_clusters)+".pdf")