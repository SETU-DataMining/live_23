import numpy as np

lambdas = [0.01, 1, 100, 10000]
coefficients = np.zeros(shape=(nP, len(lambdas)))
i=0
for l in lambdas:
    ridgeReg = Ridge(alpha=l)
    ridgeReg.fit(scaledX, y)
    coefficients[:,i] = ridgeReg.coef_
    i += 1