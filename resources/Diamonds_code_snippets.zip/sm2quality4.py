resFig = "res/simpleModel2_quality_4plot.pdf"
fig = sm.graphics.plot_regress_exog(simpleModel2, "quality")
fig.tight_layout(pad=1.0)
fig.savefig(resFig)