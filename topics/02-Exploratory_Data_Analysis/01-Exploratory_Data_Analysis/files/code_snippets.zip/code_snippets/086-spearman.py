columns = df.columns[:12]
coor = df[columns].corr(method='spearman')
coor