resFig = "res/residHist2.pdf"
sns_plot = sns.displot(x = residuals2, kde=True)
sns_plot.savefig(resFig)