import numpy as np

from sklearn.metrics import accuracy_score

from keras.models import Sequential
from keras.layers.core import Dense, Dropout, Activation
from tensorflow.keras.optimizers import SGD

X = np.array( [[0,0],[0,1],[1,0],[1,1]] )
y = np.array( [[0],[1],[1],[0]] )

def initialize_weights(shape, dtype=None):
    return np.random.normal(loc=0.75, scale=1e-2, size=shape)

def summary(model, X, y):
    pred_prob = model.predict(X)
    pred = np.array(pred_prob>0.5, dtype=int)
    print(f"{'Pred prob:':12s} {pred_prob.reshape(4)}")
    print(f"{'Pred:':12s} {pred.reshape(4)}")
    print(f"{'True:':12s} {y.reshape(4)}")
    print(f"{'Accuracy:':12s} {accuracy_score(y, pred)}")