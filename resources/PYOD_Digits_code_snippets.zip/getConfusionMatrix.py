from sklearn.metrics import confusion_matrix
confusion_matrix(y_test, y_test_pred)